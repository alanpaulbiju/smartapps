package com.example.countryinfoapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnUAE = findViewById<LinearLayout>(R.id.btnUAE)
        val btnCanada = findViewById<LinearLayout>(R.id.btnCanada)
        val btnJapan = findViewById<LinearLayout>(R.id.btnJapan)
        val btnBrazil = findViewById<LinearLayout>(R.id.btnBrazil)
        val btnFrance = findViewById<LinearLayout>(R.id.btnFrance)
        val btnEgypt = findViewById<LinearLayout>(R.id.btnEgypt)
        val btnGermany = findViewById<LinearLayout>(R.id.btnGermany)
        val btnIndia = findViewById<LinearLayout>(R.id.btnIndia)
        val btnItaly = findViewById<LinearLayout>(R.id.btnItaly)
        val btnSouthAfrica = findViewById<LinearLayout>(R.id.btnSouthAfrica)
        val btnInfo = findViewById<Button>(R.id.btnInfo)

        btnUAE.setOnClickListener { openCountryDetail("United Arab Emirates") }
        btnCanada.setOnClickListener { openCountryDetail("Canada") }
        btnJapan.setOnClickListener { openCountryDetail("Japan") }
        btnBrazil.setOnClickListener { openCountryDetail("Brazil") }
        btnFrance.setOnClickListener { openCountryDetail("France") }
        btnEgypt.setOnClickListener { openCountryDetail("Egypt") }
        btnGermany.setOnClickListener { openCountryDetail("Germany") }
        btnIndia.setOnClickListener { openCountryDetail("India") }
        btnItaly.setOnClickListener { openCountryDetail("Italy") }
        btnSouthAfrica.setOnClickListener { openCountryDetail("South Africa") }

        btnInfo.setOnClickListener {
            val dialogView = layoutInflater.inflate(R.layout.dialog_info, null)
            val dialog = android.app.AlertDialog.Builder(this).setView(dialogView).create()
            dialogView.findViewById<Button>(R.id.btnClose).setOnClickListener { dialog.dismiss() }
            dialog.show()
        }
    }

    private fun openCountryDetail(countryName: String) {
        val intent = Intent(this, detail::class.java)
        intent.putExtra("country_name", countryName)
        startActivity(intent)
    }
}
