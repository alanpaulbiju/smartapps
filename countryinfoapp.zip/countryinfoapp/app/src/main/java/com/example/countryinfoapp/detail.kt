package com.example.countryinfoapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.countryinfoapp.databinding.ActivityDetailBinding

class detail : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val countryName = intent.getStringExtra("country_name") ?: "Unknown"
        binding.txtCountryName.text = countryName

        // Country data
        when (countryName) {
            "United Arab Emirates" -> setDetails(
                capital = "Abu Dhabi",
                region = "Middle East",
                language = "Arabic",
                currency = "Dirham (AED)",
                flagRes = R.drawable.uae,
                fact = "UAE has the tallest building in the world!"
            )

            "Japan" -> setDetails(
                capital = "Tokyo",
                region = "Asia",
                language = "Japanese",
                currency = "Yen (JPY)",
                flagRes = R.drawable.japan,
                fact = "Japan has more pets than children!"
            )

            "Canada" -> setDetails(
                capital = "Ottawa",
                region = "North America",
                language = "English & French",
                currency = "Canadian Dollar (CAD)",
                flagRes = R.drawable.canada,
                fact = "Canada has the longest coastline in the world."
            )

            "Brazil" -> setDetails(
                capital = "Brasília",
                region = "South America",
                language = "Portuguese",
                currency = "Real (BRL)",
                flagRes = R.drawable.brazil,
                fact = "Brazil is home to the Amazon rainforest."
            )

            "France" -> setDetails(
                capital = "Paris",
                region = "Europe",
                language = "French",
                currency = "Euro (EUR)",
                flagRes = R.drawable.france,
                fact = "France is the most visited country in the world."
            )

            "Egypt" -> setDetails(
                capital = "Cairo",
                region = "Africa",
                language = "Arabic",
                currency = "Egyptian Pound (EGP)",
                flagRes = R.drawable.egypt,
                fact = "Egypt is home to the only remaining ancient wonder: the pyramids."
            )

            "Germany" -> setDetails(
                capital = "Berlin",
                region = "Europe",
                language = "German",
                currency = "Euro (EUR)",
                flagRes = R.drawable.germany,
                fact = "Germany is known for its engineering and beer culture."
            )

            "India" -> setDetails(
                capital = "New Delhi",
                region = "Asia",
                language = "Hindi, English",
                currency = "Indian Rupee (INR)",
                flagRes = R.drawable.india,
                fact = "India is the largest democracy in the world."
            )

            "Italy" -> setDetails(
                capital = "Rome",
                region = "Europe",
                language = "Italian",
                currency = "Euro (EUR)",
                flagRes = R.drawable.italy,
                fact = "Italy has more UNESCO heritage sites than any other country."
            )

            "South Africa" -> setDetails(
                capital = "Pretoria",
                region = "Africa",
                language = "11 official languages",
                currency = "South African Rand (ZAR)",
                flagRes = R.drawable.southafrica,
                fact = "It has 3 capital cities!"
            )

            else -> setDetails(
                capital = "Unknown",
                region = "Unknown",
                language = "Unknown",
                currency = "Unknown",
                flagRes = R.mipmap.ic_launcher,
                fact = "No information available."
            )
        }

        binding.btnBack.setOnClickListener {
            finish() // go back to previous page
        }
    }

    private fun setDetails(
        capital: String,
        region: String,
        language: String,
        currency: String,
        flagRes: Int,
        fact: String
    ) {
        binding.txtCapital.text = "Capital: $capital"
        binding.txtRegion.text = "Region: $region"
        binding.txtLanguage.text = "Language: $language"
        binding.txtCurrency.text = "Currency: $currency"
        binding.txtFact.text = "Fun Fact: $fact"
        binding.imgFlag.setImageResource(flagRes)
    }
}
