package com.example.vibecalctheemojimooddecoder

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment

class InfoDialog : DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return AlertDialog.Builder(requireContext())
            .setTitle("How to Use VibeCalc")
            .setMessage("Tap emojis to select your mood. Then hit 'Calculate Vibe' to see your result.")
            .setPositiveButton("Got it") { dialog, _ -> dialog.dismiss() }
            .create()
    }
}
