package com.example.vibecalctheemojimooddecoder


import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.vibecalctheemojimooddecoder.InfoDialog
import com.example.vibecalctheemojimooddecoder.R


class MainActivity : AppCompatActivity() {
    private val selectedEmojis = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val emoji1 = findViewById<Button>(R.id.emoji1)
        val emoji2 = findViewById<Button>(R.id.emoji2)
        val emoji3 = findViewById<Button>(R.id.emoji3)
        val calculateBtn = findViewById<Button>(R.id.calculateBtn)
        val vibeResult = findViewById<TextView>(R.id.vibeResult)

        val emojiButtons = listOf(emoji1, emoji2, emoji3)

        emojiButtons.forEach { button ->
            button.setOnClickListener {
                selectedEmojis.add(button.text.toString())
                button.isEnabled = false
            }
        }

        calculateBtn.setOnClickListener {
            val result = when {
                selectedEmojis.containsAll(listOf("😎", "💼")) -> "CEO Mode Activated"
                selectedEmojis.containsAll(listOf("📱", "😎")) -> "Cool Techie Vibes"
                else -> "You're a Mystery Vibe 😶"
            }

            vibeResult.text = result
        }
    }
}
